export JAVA_HOME=/usr/lib/jvm/amazoncorretto-11-jdk-hotspot
