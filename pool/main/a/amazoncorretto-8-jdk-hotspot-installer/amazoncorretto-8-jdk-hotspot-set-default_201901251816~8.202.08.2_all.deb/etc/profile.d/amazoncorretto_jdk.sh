export JAVA_HOME=/usr/lib/jvm/amazoncorretto-8-jdk-hotspot
